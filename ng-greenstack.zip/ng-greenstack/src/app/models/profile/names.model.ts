export class Names {
  nameType: string;
  firstName: string;
  personTitle: string;
  lastName: string;
  nameFormat: string;
  formOfAddress: string;
  name: string;
  middleName: string;
  suffix: string;
  effectiveDate: string;
  uniqueId: number;
  reasonChangeCode: string;
}
