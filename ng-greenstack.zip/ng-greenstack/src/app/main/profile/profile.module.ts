import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";

import { PROFILE_ROUTES } from "./profile.routing";
import { ProfileComponent } from "./profile.component";

@NgModule({
  declarations: [
    ProfileComponent
  ],
  imports: [
    RouterModule.forChild(PROFILE_ROUTES)
  ],
  providers: [

  ]
})
export class ProfileModule { }
