import { Routes } from '@angular/router';
import { MainComponent } from "./main.component";
import { DashBoardComponent } from "./dashboard/dashboard.component";

export const MAIN_ROUTES: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashBoardComponent },
      { path: 'profile', loadChildren: 'app/main/profile/profile.module#ProfileModule'}
    ]
  }
];
