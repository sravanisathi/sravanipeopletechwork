import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";

import { MAIN_ROUTES } from './main.routing';
import { MainComponent } from "./main.component";
import { DashBoardComponent } from "./dashboard/dashboard.component";
import { HeaderBarComponent } from './header-bar/header-bar.component';
import { MenuComponent } from './menu/menu.component';

@NgModule({
  declarations: [
    MainComponent,
    DashBoardComponent,
    HeaderBarComponent,
    MenuComponent
  ],
  imports: [
    RouterModule.forChild(MAIN_ROUTES)
  ],
  providers: [

  ]
})
export class MainModule { }
