
import { NgModule } from '@angular/core';

const SHARED_COMPONENTS = [];

@NgModule({
  declarations: [...SHARED_COMPONENTS],
  imports: [],
  providers: [],
  exports: [...SHARED_COMPONENTS]
})
export class SharedModule { }
