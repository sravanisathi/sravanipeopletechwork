export class ApiConstants {
  private _ApiUrl2: string = "/api-content";
  private _ApiVersion: string = "/v1";
}
