import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from "@angular/router";
import * as $ from 'jquery';
import { AppService } from "./shared/app.service";
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import { LoadersCssModule } from 'angular2-loaders-css';
import { SimpleNotificationsModule, NotificationsService } from 'angular2-notifications';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterPageComponent } from './register-page/register-page.component';
import { DashboardDeploymentComponent } from './dashboard-deployment/dashboard-deployment.component';
import { MainDeploymentComponent } from './main-deployment/main-deployment.component';
import { TenantDashboardComponent } from './tenant-dashboard/tenant-dashboard.component';
import { AlltenantdashboardComponent } from './alltenantdashboard/alltenantdashboard.component';
import { CompanyInformationComponent } from './company-information/company-information.component';
import { AgGridModule } from "ag-grid-angular/main";
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { MyDatePickerModule } from 'mydatepicker';
import { HostPoolDashboardComponent } from './host-pool-dashboard/host-pool-dashboard.component';
import { ClipboardDirective } from './host-pool-dashboard/hostpoolclipboard.directive';
import { DeploymentDashboardComponent } from './deployment-dashboard/deployment-dashboard.component';
import { AppUserComponent } from './app-user/app-user.component';
import { HelpComponent } from './help/help.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { DiagnosticsComponent } from './diagnostics/diagnostics.component';
import { TechnicalComponent } from './technical/technical.component';
import { SalesComponentComponent } from './sales-component/sales-component.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ConfigurationComponent } from './configuration/configuration.component';
//import { ConfigurationService } from "./configuration/configuration.service";
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    HomepageComponent,
    RegisterPageComponent,
    DashboardDeploymentComponent,
    MainDeploymentComponent,
    DeploymentDashboardComponent,
    TenantDashboardComponent,
    AlltenantdashboardComponent,
    CompanyInformationComponent,
    HostPoolDashboardComponent,
    ClipboardDirective,
    AppUserComponent,
    HelpComponent,
    PermissionsComponent,
    DiagnosticsComponent,
    TechnicalComponent,
    SalesComponentComponent,
    ConfigurationComponent,

  ],
  imports: [
    BrowserModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule,
    //NoopAnimationsModule,
    SimpleNotificationsModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    LoadersCssModule,
    MyDatePickerModule,
    AgGridModule.withComponents([]),
    RouterModule.forRoot([
      {
        path: '',
        component: LoginComponent
      },
      {
        path: 'MainDeploymentComponent',
        component: MainDeploymentComponent
      },
      {
        path: 'Registration',
        component: RegisterPageComponent
      },
      {
        path: 'dashboard',
        component: DashboardComponent,
        children: [

          {
            path: '',
            component: HomepageComponent
          },
          {
            path: 'new',
            component: HomepageComponent
          },
          //{
          //  path: 'DashboardDeployment',
          //  component: DashboardDeploymentComponent
          //},
          //{
          //  path: 'DeploymentDashboard',
          //  component: DeploymentDashboardComponent
          //},
          {
            path: 'TenantDashboard',
            component: TenantDashboardComponent
          },
          {
              path: 'TenantDashboards',
              component: TenantDashboardComponent
          },
          {
            path: 'AllTenantDashboard',
            component: AlltenantdashboardComponent
          },
          {
            path: 'HostPollDashboard',
            component: HostPoolDashboardComponent
          },
          {
              path: 'HostPollDashboards',
              component: HostPoolDashboardComponent
          },
          {
            path: 'companyInfo',
            component: CompanyInformationComponent
          },
          {
            path: 'AppUser',
            component: AppUserComponent
          },
          {
            path: 'help',
            component: HelpComponent
          },
          {
            path: 'Permissions',
            component: PermissionsComponent
          },
          {
            path: 'diagnostics',
            component: DiagnosticsComponent
          },
          {
            path: 'Technical ',
            component: TechnicalComponent
          },
          {
            path: 'SalesComponent ',
            component: SalesComponentComponent
          },
          {
              path: 'Configuration',
              component: ConfigurationComponent
          },
        ]
      }
           
    ]),
  ],
  providers: [AppService, NotificationsService,{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }



