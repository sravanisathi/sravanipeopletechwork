/**
 * Created by Sravani on 9/19/2017.
 */

//The maximum is exclusive and the minimum is inclusive
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

console.log(getRandomInt(40, 50));

var field1 = getRandomInt(40, 50);
var field2 = getRandomInt(40, 50);
var options = {
    field1: field1,
    field2: field2,
    answer: field1 + field2,
    arrayListOfOptions: [],
    sortedListOfOptions: []
};



for (var i = 0; i <= 3; i++) {
    var value = getRandomInt(40, 50);
    if (options.arrayListOfOptions.indexOf(value) > -1)
        options.arrayListOfOptions.push(value);
}



options.arrayListOfOptions.push(options.answer);

options.sortedListOfOptions = options.arrayListOfOptions.sort(function (a, b) {
    return 0.5 - Math.random();
});
