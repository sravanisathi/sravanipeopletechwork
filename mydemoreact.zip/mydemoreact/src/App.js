import React, { Component } from 'react';
import './App.css';
import { Button, Panel, Form, FormGroup, Col, ControlLabel, FormControl, Table } from 'react-bootstrap';

class App extends Component {

    constructor() {
        super();
        this.projectsLIst = [];
    }


    addProject(e) {
        if (e.target.projectTitle.value && e.target.projectType.value) {
            this.projectsLIst.push({
                id: this.projectsLIst.length + 1,
                title: e.target.projectTitle.value,
                type: e.target.projectType.value
            });
            this.setState(this.projectsLIst);
            e.target.projectTitle.value = '';
            e.target.projectType.value = '';
            e.preventDefault();
        } else {
            alert('Please fill the fields....');
            e.preventDefault();
        }

    }

    deleteRow(index) {
        this.projectsLIst.splice(index, 1);
        this.setState(this.projectsLIst);
    }

    render() {
        return (
            <div className="App">
                <Panel header="Projects Info" bsStyle="info">

                    <form onSubmit={this.addProject.bind(this)}>
                        <FormGroup controlId="formHorizontalPassword">
                            <Col componentClass={ControlLabel} sm={2}>
                                Project Title
                            </Col>
                            <Col sm={5}>
                                <FormControl type="text" name="projectTitle" id="projectTitle"/>
                            </Col>
                        </FormGroup>
                        <FormGroup controlId="formControlsSelect">
                            <Col componentClass={ControlLabel} sm={2}>
                                Project Type
                            </Col>
                            <Col sm={5}>
                                <FormControl name="projectType" id="projectType" componentClass="select" placeholder="select">
                                    <option value="select">select</option>
                                    <option value="mobile">Mobile</option>
                                    <option value="hybrid">Hybrid</option>
                                </FormControl>
                            </Col>
                        </FormGroup>
                        <FormGroup>
                            <Col smOffset={2} sm={5}>
                                <Button type="submit" bsStyle="primary">Add Project</Button>
                            </Col>
                        </FormGroup>
                    </form>
                </Panel>


                <Panel header="Projects List" bsStyle="info">
                    <Table striped condensed hover>
                        <thead>
                        <tr>
                            <th>Project Title</th>
                            <th>Project Type</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        {this.projectsLIst.map(function (obj, index) {
                            return <tr key={index}>
                                <td>{obj.title}</td>
                                <td>{obj.type}</td>
                                <td><Button bsStyle="danger" onClick={() => { this.deleteRow(index) }}>Remove</Button></td>
                            </tr>
                        }, this)}
                        </tbody>
                    </Table>
                </Panel>
            </div>
        );
    }
}

export default App;
