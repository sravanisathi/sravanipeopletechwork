{/*
/!**
 * Created by Sravani on 8/3/2017.
 *!/
import React from 'react';
import Example1 from './Example1/Example1.jsx'
class Example extends React.Component{
    onClick = () => {
        this.example1.method()
    }
    alertFunction(msg){
        alert(msg);
    }

    constructor(){
        super();
        this.props.func(this, 1234);
        this.state={
            child: Example1,
            data:[
                {
                    "id":8124,
                    "name":"Sujatha",
                    "age":"40"
                },

                {
                    "id":8125,
                    "name":"Sathi",
                    "age":"30"
                },

                {
                    "id":8126,
                    "name":"sravani",
                    "age":"21"
                }
            ]

        }


    }


    render() {
        return (

            <div>
                <Header/>
                <table>
                    <tbody>
                    {this.state.data.map((emp, i) => <EmployeeDetails key = {i} data = {emp}/>)}
                    </tbody>
                </table>
                <Example1/>


                <AlertMessage alertFunction={this.alertFunction.bind(this)} />
            </div>



        );
    }

}


class Header extends React.Component {
    render() {
        return (
            <div>
                <h1>Employee Details</h1>
            </div>
        );
    }
}

class EmployeeDetails extends React.Component {
    render() {
        return (
            <div>
            <tr>
                <td>{this.props.data.id}</td>
                <td>{this.props.data.name}</td>
                <td>{this.props.data.age}</td>
            </tr>
                </div>
        );
    }

}
class AlertMessage extends React.Component{
    render(){
        return (

            <button onClick={ event => {
                this.props.alertFunction("message from child") }
            }>Send a Message to Parent </button>


        );

    }

}
export default Example;
*/}
