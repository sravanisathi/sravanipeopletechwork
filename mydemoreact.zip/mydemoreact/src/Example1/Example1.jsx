/*
/!**
 * Created by Sravani on 8/7/2017.
 *!/
import React from 'react';
import Example from '../Example'
class Example1 extends React.Component {
    constructor() {
        super();

        this.state = {
            student: [
                {
                    id: 995,
                    name: 'x',
                    marks: 990
                },
                {
                    id: 996,
                    name: 'y',
                    marks: 880
                },
                {
                    id: 997,
                    name: 'z',
                    marks: 855
                }

            ],

            checkClick(e, notyId) {
                alert(notyId);
            }

        }
    }

    render() {
        return (
            <div>
                <Header/>
                <table>
                    <tbody>
                    {this.state.student.map((stu, i) => <StudentDetails key = {i} data = {stu} />)}
                    </tbody>
                </table>
                <Example  func ={this.checkClick()}/>
            </div>
        );
    }
}
    class Header extends React.Component{
    render() {
        return (
            <div>
                <h1>Student Details</h1>
            </div>
        );
    }
}

class StudentDetails extends React.Component {
    render() {
        return (
            <tr>
                <td>{this.props.data.id}</td>
                <td>{this.props.data.name}</td>
                <td>{this.props.data.marks}</td>
            </tr>
        );
    }

}
export default Example1;*/
