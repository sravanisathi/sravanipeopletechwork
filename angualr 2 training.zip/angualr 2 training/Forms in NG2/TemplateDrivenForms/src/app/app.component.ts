import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  firstname: any;
  middlename: any;
  lastname: any;
  city: any;
  pincode: any;

  ngOnInit() {
    this.firstname = "people";
    this.middlename = "Tech";
    this.lastname = "Group";
    this.city = "hyderabad";
    this.pincode = "12345"
  }

  submitForm(value:any){
    console.log(value);
  }
}
