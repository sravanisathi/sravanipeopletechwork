module.exports = {
  SHOW_ALL: 'show_all',
  SHOW_COMPLETED: 'show_completed',
  SHOW_ACTIVE: 'show_active'
};
