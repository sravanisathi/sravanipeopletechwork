/**
 * Created by Sravani on 3/22/2018.
 */
module.exports = {
  template: require('./ProductFilter.html'),
  controller: ProductComponentController
};

function ProductComponentController() {
  
}
