/**
 * Created by Sravani on 3/20/2018.
 */


module.exports = {
  template: require('./ProductFilter.html'),
  controller: ProductFilter,
  bindings: {

  }
};


/** @ngInject */
function ProductFilter() {
  function dummy() {
    alert("hai");
  }



// json for populating dropdowns

  this.productInfo = [
    {
      availableItems: [
        {id: 1, name: "mobile"},
        {id: 2, name: "ac"},
        {id: 3, name: "tv"},
        {id: 4, name: "fridze"}
      ],
      availablePlan: [
        {id: 1, name: "plan1"},
        {id: 2, name: "plan2"},
        {id: 3, name: "plan3"},
        {id: 4, name: "plan4"}
      ],
      price: {
        minValue: 0,
        maxValue: 100000,
        options: {
          floor: 0,
          ceil: 100000,
          onChange: onChangeFn
        }
      }
    }
  ];


  this.productInfo[0].price.options.onChange = this.productInfo[0].price.options.onChange.bind(this);


  // json for populating table

  this.arr = [
    {
      itemName: 'mobile',
      planType: 'plan1',
      price: 200
    },
    {
      itemName: 'mobile',
      planType: 'plan2',
      price: 1200
    },
    {
      itemName: 'mobile',
      planType: 'plan3',
      price: 3200
    },
    {
      itemName: 'ac',
      planType: 'plan3',
      price: 32040
    },
    {
      itemName: 'ac',
      planType: 'plan4',
      price: 32040
    },
    {
      itemName: 'tv',
      planType: 'plan4',
      price: 3255040
    }

  ];

  this.arrCopy = angular.copy(this.arr);

  function onChangeFn(sliderId, modelValue) {
    this.selectedItemprice = modelValue;
    var _that = this;
    _that.customFilter();

  }


  this.selectedAvailableItem  = '';
  this.selectedAvailablePlan  = '';

  this.customFilter = function () {
    var _that = this;

    //if price only selected : filter by price
    if (!this.selectedAvailablePlan && !this.selectedAvailableItem) {
      this.arr = this.arrCopy.filter(function (product) {
        return ((product.price >= _that.productInfo[0].price.minValue) && (product.price <= _that.productInfo[0].price.maxValue));
      });
    }
    // if name only selected : filter by name & price
    if (!this.selectedAvailablePlan && this.selectedAvailableItem) {
      this.arr = this.arrCopy.filter(function (product) {
        return (product.itemName === _that.selectedAvailableItem) && ((product.price >= _that.productInfo[0].price.minValue) && (product.price <= _that.productInfo[0].price.maxValue));
      });
    }
    //if plan only selected : filter by plan & price
    if (this.selectedAvailablePlan && !this.selectedAvailableItem) {
      this.arr = this.arrCopy.filter(function (product) {
        return (product.planType === _that.selectedAvailablePlan) && ((product.price >= _that.productInfo[0].price.minValue) && (product.price <= _that.productInfo[0].price.maxValue));
      });
    }
    //if name & plan selected : filter by name,plan & price
    if (this.selectedAvailablePlan && this.selectedAvailableItem) {
      this.arr = this.arrCopy.filter(function (product) {
        return (product.itemName === _that.selectedAvailableItem) && (product.planType === _that.selectedAvailablePlan) && ((product.price >= _that.productInfo[0].price.minValue) && (product.price <= _that.productInfo[0].price.maxValue));
      });
    }


  }







}


